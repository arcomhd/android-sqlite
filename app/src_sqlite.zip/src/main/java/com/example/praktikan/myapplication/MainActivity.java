package com.example.praktikan.myapplication;

import android.content.ContentValues;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public EditText id;
    public EditText name;
    public EditText university;
    public EditText subject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        id = (EditText) findViewById(R.id.inputID);
        name = (EditText) findViewById(R.id.inputName);
        university = (EditText) findViewById(R.id.inputUniversity);
        subject = (EditText) findViewById(R.id.inputSubject);
    }

    public void addAction(View view) {
        String idString = id.getText().toString();
        String nameString = name.getText().toString();
        String universityString = university.getText().toString();
        String subjectString = subject.getText().toString();

        AdminSQLiteOpenHelper sqlite = new AdminSQLiteOpenHelper(this, "management", null, 1);
        SQLiteDatabase db = sqlite.getWritableDatabase();
        ContentValues registry = new ContentValues();
        registry.put("id", idString);
        registry.put("name", nameString);
        registry.put("university", universityString);
        registry.put("subject", subjectString);
        db.insert("people", null, registry);
        db.close();
        Toast.makeText(this, "Data berhasil ditambahkan", Toast.LENGTH_SHORT).show();

    }

    public void showAction(View view){
        String idString = id.getText().toString();
        AdminSQLiteOpenHelper sqlite =
                new AdminSQLiteOpenHelper(this, "management", null, 1);
        SQLiteDatabase db = sqlite.getWritableDatabase();
        Cursor row = db.rawQuery("SELECT name, university, subject FROM people WHERE id="
                + idString, null);
        if(row.moveToFirst()){
            name.setText(row.getString(0));
            university.setText(row.getString(1));
            subject.setText(row.getString(2));
        } else {
            Toast.makeText(this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
        }
        db.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
